<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class HomeController extends Controller
{
    public function index()
    {
        $data = [
            'submitted_name' => session()->getFlashdata('submitted_name'),
            'submitted_comment' => session()->getFlashdata('submitted_comment'),
            'error' => session()->getFlashdata('error')
        ];
        
        return view('form_view', $data);
    }
    
    public function submit()
    {
        $name = $this->request->getPost('user_name');
        $comment = $this->request->getPost('user_comment');
        
        session()->setFlashdata('submitted_name', $name);
        session()->setFlashdata('submitted_comment', $comment);
        
        return redirect()->to('/');
    }
}