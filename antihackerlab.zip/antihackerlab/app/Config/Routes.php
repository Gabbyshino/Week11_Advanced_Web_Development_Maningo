<?php

namespace Config;

// Get the router service
$routes = \Config\Services::routes();

/**
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(false);

/**
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 * 
 * TASK 01, 02, 03: Anti-Hacker Lab Routes
 * These are the only routes we need for our lab.
 */

// Home page - displays the form
$routes->get('/', 'HomeController::index');

// Form submission - handles POST requests with CSRF protection
$routes->post('/submit', 'HomeController::submit');

/**
 * --------------------------------------------------------------------
 * IMPORTANT: DO NOT add any self-referential includes here!
 * The lines below were causing the infinite loop.
 * --------------------------------------------------------------------
 */