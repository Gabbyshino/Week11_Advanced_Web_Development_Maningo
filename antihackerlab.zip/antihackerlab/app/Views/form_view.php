<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anti-Hacker Lab | CSRF & XSS Protection</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background-color: #f5f5f5;
            line-height: 1.5;
            color: #2c3e50;
            padding: 40px 20px;
        }
        
        .container {
            max-width: 800px;
            width: 100%;
            margin: 0 auto;
            background: #ffffff;
            border-radius: 4px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        
        .header {
            background: #2c3e50;
            padding: 32px 40px;
            border-bottom: 2px solid #e74c3c;
            text-align: center;
        }
        
        .header h1 {
            color: #ffffff;
            font-size: 28px;
            font-weight: 500;
            margin-bottom: 8px;
        }
        
        .header p {
            color: #bdc3c7;
            font-size: 14px;
            font-weight: 400;
        }
        
        .content {
            padding: 40px;
        }
        
        .alert {
            padding: 14px 18px;
            margin-bottom: 28px;
            border-radius: 3px;
            font-size: 14px;
            border-left: 3px solid;
            text-align: center;
        }
        
        .alert-success {
            background-color: #e8f8f5;
            border-left-color: #27ae60;
            color: #1e8449;
        }
        
        .alert-error {
            background-color: #fdedec;
            border-left-color: #e74c3c;
            color: #c0392b;
        }
        
        .form-group {
            margin-bottom: 24px;
        }
        
        label {
            display: block;
            font-weight: 500;
            margin-bottom: 8px;
            color: #2c3e50;
            font-size: 14px;
        }
        
        input[type="text"],
        textarea {
            width: 100%;
            padding: 12px 14px;
            border: 1px solid #dcdfe6;
            border-radius: 3px;
            font-size: 15px;
            font-family: 'Courier New', monospace;
            transition: all 0.2s ease;
            background: #ffffff;
        }
        
        textarea {
            resize: vertical;
            min-height: 100px;
        }
        
        input[type="text"]:focus,
        textarea:focus {
            outline: none;
            border-color: #3498db;
            box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.1);
        }
        
        button {
            background-color: #2c3e50;
            color: #ffffff;
            border: none;
            padding: 12px 28px;
            font-size: 14px;
            font-weight: 500;
            border-radius: 3px;
            cursor: pointer;
            transition: background-color 0.2s ease;
            display: block;
            margin: 0 auto;
        }
        
        button:hover {
            background-color: #e74c3c;
        }
        
        .divider {
            margin: 32px 0;
            border: none;
            border-top: 1px solid #ecf0f1;
        }
        
        .output-section {
            margin-top: 8px;
            text-align: center;
        }
        
        .output-section h3 {
            font-size: 16px;
            font-weight: 500;
            color: #2c3e50;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        
        .badge {
            display: inline-block;
            background-color: #ecf0f1;
            color: #2c3e50;
            font-size: 11px;
            font-weight: 500;
            padding: 2px 8px;
            border-radius: 20px;
            letter-spacing: 0.3px;
        }
        
        .output-item {
            margin-bottom: 24px;
            text-align: left;
            max-width: 500px;
            margin-left: auto;
            margin-right: auto;
        }
        
        .output-label {
            font-weight: 600;
            font-size: 13px;
            color: #7f8c8d;
            margin-bottom: 6px;
            text-align: center;
        }
        
        .output-box {
            background-color: #fafbfc;
            border: 1px solid #e9ecef;
            border-radius: 3px;
            padding: 16px;
            font-family: 'Courier New', 'SF Mono', monospace;
            font-size: 14px;
            word-wrap: break-word;
            white-space: pre-wrap;
            color: #2c3e50;
            text-align: center;
        }
        
        .output-box em {
            color: #95a5a6;
            font-style: italic;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }
        
        .tasks-status {
            background-color: #fafbfc;
            border: 1px solid #e9ecef;
            border-radius: 3px;
            padding: 24px;
            margin-top: 32px;
        }
        
        .tasks-status h4 {
            font-size: 14px;
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 16px;
            letter-spacing: 0.3px;
            text-align: center;
        }
        
        .tasks-status ul {
            list-style: none;
            padding: 0;
            text-align: center;
        }
        
        .tasks-status li {
            padding: 8px 0;
            font-size: 13px;
            color: #555;
            border-bottom: 1px solid #ecf0f1;
        }
        
        .tasks-status li:last-child {
            border-bottom: none;
        }
        
        .tasks-status .check {
            color: #27ae60;
            font-weight: 600;
            margin-right: 8px;
        }
        
        .tasks-status code {
            background-color: #ecf0f1;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: 'Courier New', monospace;
            font-size: 12px;
            color: #e74c3c;
        }
        
        .footer {
            background-color: #fafbfc;
            padding: 16px 40px;
            border-top: 1px solid #ecf0f1;
            font-size: 12px;
            color: #95a5a6;
            text-align: center;
        }
        
        @media (max-width: 640px) {
            body {
                padding: 20px 16px;
            }
            .header {
                padding: 24px 24px;
            }
            .header h1 {
                font-size: 22px;
            }
            .content {
                padding: 24px;
            }
            button {
                width: 100%;
            }
            .output-item {
                max-width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🛡️ Anti-Hacker Lab</h1>
            <p>CSRF Protection & XSS Prevention Demo</p>
        </div>
        
        <div class="content">
            
            <?php if(isset($submitted_name) && $submitted_name): ?>
                <div class="alert alert-success">
                    ✓ Submission Successful! Your input has been received and escaped.
                </div>
            <?php endif; ?>
            
            <?php if(isset($error) && $error): ?>
                <div class="alert alert-error">
                    ⚠️ Error: <?= $error ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="/submit">
                <?= csrf_field() ?>
                
                <div class="form-group">
                    <label for="user_name">Name</label>
                    <input type="text" id="user_name" name="user_name" autocomplete="off">
                </div>
                
                <div class="form-group">
                    <label for="user_comment">Comment</label>
                    <textarea id="user_comment" name="user_comment" autocomplete="off"></textarea>
                </div>
                
                <button type="submit">Submit Form</button>
            </form>
            
            <hr class="divider">
            
            <div class="output-section">
                <h3>
                    📋 Submitted Data
                    <span class="badge">esc() applied</span>
                </h3>
                
                <div class="output-item">
                    <div class="output-label">Name:</div>
                    <div class="output-box">
                        <?php if(isset($submitted_name) && !empty($submitted_name)): ?>
                            <?= esc($submitted_name) ?>
                        <?php else: ?>
                            <em>No name submitted</em>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="output-item">
                    <div class="output-label">Comment:</div>
                    <div class="output-box">
                        <?php if(isset($submitted_comment) && !empty($submitted_comment)): ?>
                            <?= esc($submitted_comment) ?>
                        <?php else: ?>
                            <em>No comment submitted</em>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="tasks-status">
                <h4>✓ Lab Tasks Status</h4>
                <ul>
                    <li><span class="check">✅</span> <strong>TASK 01:</strong> CSRF Filter enabled in <code>app/Config/Filters.php</code></li>
                    <li><span class="check">✅</span> <strong>TASK 02:</strong> CSRF token added with <code>&lt;?= csrf_field() ?&gt;</code></li>
                    <li><span class="check">✅</span> <strong>TASK 03:</strong> User output escaped with <code>&lt;?= esc($data) ?&gt;</code></li>
                </ul>
            </div>
        </div>
        
        <div class="footer">
            Anti-Hacker Lab | CSRF & XSS Protection Demo
        </div>
    </div>
</body>
</html>